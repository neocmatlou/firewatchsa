FIREWATCH SA | Prepared NASA FIRMS VIIRS NOAA-21 2024-2025
Source: User-provided NASA FIRMS archive DL_FIRE_J2V-C2_828479.zip
Filter: type == 0 (presumed vegetation fire). This is not a unique wildfire event inventory.
Retained all confidence levels; use confidence field for sensitivity analyses.
Added year, month, season (South African meteorological seasons), datetime_utc.
Coordinates: longitude and latitude in degrees (WGS84 assumed from FIRMS source).
Time: FIRMS acq_time is UTC.
Records: 340776; 2024: 217164; 2025: 123612.
No provincial assignments or repeated-observation removal have yet been performed.
Statistical tests require a valid study window, projection and treatment of repeated detections.
